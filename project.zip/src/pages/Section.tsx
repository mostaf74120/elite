import React, { useState } from 'react';
import { SubscriptionForm } from '../components/SubscriptionForm';
import { Reports } from '../components/Reports';
import { Link } from 'react-router-dom';
import { Home, ListPlus, FileText } from 'lucide-react';

interface SectionProps {
  gender: 'male' | 'female';
}

export function Section({ gender }: SectionProps) {
  const [activeTab, setActiveTab] = useState<'form' | 'reports'>('form');

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          قسم {gender === 'male' ? 'البنين' : 'البنات'}
        </h1>
        <Link to="/" className="btn btn-secondary">
          <Home className="h-5 w-5" />
          العودة للرئيسية
        </Link>
      </div>

      <div className="flex gap-4 border-b border-gray-200">
        <button
          className={`btn ${
            activeTab === 'form'
              ? 'text-blue-600 border-b-2 border-blue-600 rounded-none'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('form')}
        >
          <ListPlus className="h-5 w-5" />
          إضافة اشتراك
        </button>
        <button
          className={`btn ${
            activeTab === 'reports'
              ? 'text-blue-600 border-b-2 border-blue-600 rounded-none'
              : 'text-gray-500 hover:text-gray-700'
          }`}
          onClick={() => setActiveTab('reports')}
        >
          <FileText className="h-5 w-5" />
          التقارير
        </button>
      </div>

      <div className="animate-fadeIn">
        {activeTab === 'form' ? (
          <SubscriptionForm gender={gender} />
        ) : (
          <Reports gender={gender} />
        )}
      </div>
    </div>
  );
}