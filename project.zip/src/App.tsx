import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Section } from './pages/Section';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="boys" element={<Section gender="male" />} />
          <Route path="girls" element={<Section gender="female" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;