import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { SubscriptionList } from './SubscriptionList';
import type { Subscription } from '../types';
import { FileText } from 'lucide-react';

interface ReportsProps {
  gender: 'male' | 'female';
}

export function Reports({ gender }: ReportsProps) {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSubscriptions = async () => {
      const q = query(
        collection(db, 'subscriptions'),
        where('gender', '==', gender)
      );
      const querySnapshot = await getDocs(q);
      const subs = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Subscription[];
      setSubscriptions(subs);
      setLoading(false);
    };

    fetchSubscriptions();
  }, [gender]);

  const generatePDF = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">
          تقارير اشتراكات {gender === 'male' ? 'البنين' : 'البنات'}
        </h2>
        <button
          onClick={generatePDF}
          className="btn btn-success"
        >
          <FileText className="h-5 w-5" />
          تصدير PDF
        </button>
      </div>

      {loading ? (
        <div className="text-center py-8">جاري التحميل...</div>
      ) : (
        <SubscriptionList subscriptions={subscriptions} />
      )}
    </div>
  );
}