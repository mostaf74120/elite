import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

export const formatDate = (date: string | Date) => {
  return format(new Date(date), 'dd/MM/yyyy', { locale: ar });
};

export const getPaymentMethodLabel = (method: string) => {
  switch (method) {
    case 'cash':
      return 'كاش';
    case 'network':
      return 'شبكة';
    case 'credit':
      return 'بطاقة ائتمان';
    default:
      return method;
  }
};

export const getPaymentMethodStyle = (method: string) => {
  switch (method) {
    case 'cash':
      return 'bg-green-100 text-green-800';
    case 'network':
      return 'bg-blue-100 text-blue-800';
    case 'credit':
      return 'bg-purple-100 text-purple-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};