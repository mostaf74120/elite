import React from 'react';
import { getPaymentMethodLabel, getPaymentMethodStyle } from '../lib/utils';

interface PaymentMethodBadgeProps {
  method: string;
}

export function PaymentMethodBadge({ method }: PaymentMethodBadgeProps) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPaymentMethodStyle(method)}`}>
      {getPaymentMethodLabel(method)}
    </span>
  );
}