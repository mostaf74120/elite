import React from 'react';
import { Link } from 'react-router-dom';
import { Users, UserRound } from 'lucide-react';

export function Home() {
  return (
    <div className="text-center space-y-12">
      <div className="space-y-4">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          مرحباً بكم في مركز النخبة التعليمي
        </h1>
        <p className="text-gray-600 text-xl">
          نظام إدارة الاشتراكات والدورات التعليمية
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <Link
          to="/boys"
          className="card p-8 group"
        >
          <Users className="h-20 w-20 text-blue-600 mb-6 mx-auto transform transition-transform group-hover:scale-110" />
          <h2 className="text-2xl font-bold text-gray-900">قسم البنين</h2>
          <p className="mt-2 text-gray-600">إدارة اشتراكات ودورات الطلاب</p>
        </Link>
        
        <Link
          to="/girls"
          className="card p-8 group"
        >
          <UserRound className="h-20 w-20 text-pink-600 mb-6 mx-auto transform transition-transform group-hover:scale-110" />
          <h2 className="text-2xl font-bold text-gray-900">قسم البنات</h2>
          <p className="mt-2 text-gray-600">إدارة اشتراكات ودورات الطالبات</p>
        </Link>
      </div>
    </div>
  );
}