import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyB2qQsA6ugleF4ioabU43872ARRB16Gq2o",
  authDomain: "elite-87eae.firebaseapp.com",
  projectId: "elite-87eae",
  storageBucket: "elite-87eae.firebasestorage.app",
  messagingSenderId: "7822457198",
  appId: "1:7822457198:web:cedc143972cd2c7a83297f",
  measurementId: "G-42R0XCJN37"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const analytics = getAnalytics(app);