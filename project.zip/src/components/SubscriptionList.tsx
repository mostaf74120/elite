import React from 'react';
import { formatDate } from '../lib/utils';
import { PaymentMethodBadge } from './PaymentMethodBadge';
import type { Subscription } from '../types';

interface SubscriptionListProps {
  subscriptions: Subscription[];
}

export function SubscriptionList({ subscriptions }: SubscriptionListProps) {
  if (subscriptions.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl shadow-lg border border-gray-100">
        <p className="text-gray-500">لا توجد اشتراكات مسجلة</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-xl shadow-lg border border-gray-100">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 bg-white">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">الاسم</th>
              <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">تاريخ الدورة</th>
              <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">المبلغ</th>
              <th className="px-6 py-4 text-right text-sm font-semibold text-gray-900">طريقة الدفع</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 bg-white">
            {subscriptions.map((sub) => (
              <tr key={sub.id} className="hover:bg-gray-50 transition-colors duration-150">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                  {sub.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {formatDate(sub.date)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <span className="font-semibold">{sub.amount}</span> ريال
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <PaymentMethodBadge method={sub.paymentMethod} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}