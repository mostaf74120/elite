export interface Subscription {
  id?: string;
  name: string;
  date: string;
  amount: number;
  paymentMethod: 'cash' | 'network' | 'credit';
  gender: 'male' | 'female';
  createdAt: Date;
}