import React, { useState } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import type { Subscription } from '../types';
import { Save } from 'lucide-react';

interface SubscriptionFormProps {
  gender: 'male' | 'female';
}

export function SubscriptionForm({ gender }: SubscriptionFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    date: '',
    amount: '',
    paymentMethod: 'cash'
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const subscription: Omit<Subscription, 'id'> = {
        ...formData,
        amount: Number(formData.amount),
        gender,
        createdAt: new Date()
      };
      await addDoc(collection(db, 'subscriptions'), subscription);
      setFormData({ name: '', date: '', amount: '', paymentMethod: 'cash' });
      alert('تم إضافة الاشتراك بنجاح');
    } catch (error) {
      console.error('Error adding subscription:', error);
      alert('حدث خطأ أثناء إضافة الاشتراك');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="card p-8 space-y-6 max-w-2xl mx-auto">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">الاسم</label>
        <input
          type="text"
          required
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="input-field"
          placeholder="أدخل اسم المشترك"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">تاريخ الدورة</label>
        <input
          type="date"
          required
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          className="input-field"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">المبلغ</label>
        <input
          type="number"
          required
          value={formData.amount}
          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
          className="input-field"
          placeholder="أدخل المبلغ بالريال"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">طريقة الدفع</label>
        <select
          value={formData.paymentMethod}
          onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
          className="input-field"
        >
          <option value="cash">كاش</option>
          <option value="network">شبكة</option>
          <option value="credit">بطاقة ائتمان</option>
        </select>
      </div>
      
      <button
        type="submit"
        disabled={loading}
        className="btn btn-primary w-full justify-center"
      >
        <Save className="h-5 w-5" />
        {loading ? 'جاري الحفظ...' : 'إضافة الاشتراك'}
      </button>
    </form>
  );
}