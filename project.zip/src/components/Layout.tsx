import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import { School } from 'lucide-react';

export function Layout() {
  return (
    <div className="min-h-screen">
      <header className="bg-white/80 backdrop-blur-sm shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link to="/" className="flex items-center gap-3 group">
            <School className="h-10 w-10 text-blue-600 transform transition-transform group-hover:scale-110" />
            <span className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              مركز النخبة التعليمي
            </span>
          </Link>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>
    </div>
  );
}